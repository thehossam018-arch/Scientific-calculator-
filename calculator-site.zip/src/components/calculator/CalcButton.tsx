import { cn } from "@/lib/utils";
import type { ReactNode } from "react";

export type KeyVariant = "default" | "num" | "op" | "accent" | "alpha" | "danger";

interface Props {
  label: ReactNode;
  shiftLabel?: ReactNode;
  alphaLabel?: ReactNode;
  variant?: KeyVariant;
  active?: boolean;
  onPress: () => void;
  className?: string;
  bigLabel?: boolean;
}

const variantClass: Record<KeyVariant, string> = {
  default:
    "bg-[var(--calc-key)] hover:bg-[var(--calc-key-hi)] text-[var(--calc-key-fg)]",
  num:
    "bg-[var(--calc-key-num)] hover:bg-[var(--calc-key-num-hi)] text-[var(--calc-key-fg)]",
  op:
    "bg-[var(--calc-key-num)] hover:bg-[var(--calc-key-num-hi)] text-[var(--calc-key-fg)]",
  accent:
    "bg-gradient-to-b from-white via-[var(--calc-key-danger)] to-[var(--calc-key-danger-hi)] hover:brightness-110 text-[var(--calc-key-accent-fg)] ring-1 ring-white/60 shadow-[0_1px_0_rgba(255,255,255,0.6)_inset]",
  alpha:
    "bg-gradient-to-b from-white via-[var(--calc-key-danger)] to-[var(--calc-key-danger-hi)] hover:brightness-110 text-[var(--calc-key-alpha-fg)] ring-1 ring-white/60 shadow-[0_1px_0_rgba(255,255,255,0.6)_inset]",
  danger:
    "bg-gradient-to-b from-white via-[var(--calc-key-danger)] to-[var(--calc-key-danger-hi)] hover:brightness-110 text-[var(--calc-key-accent-fg)] ring-1 ring-white/60 shadow-[0_1px_0_rgba(255,255,255,0.6)_inset]",
};

export function CalcButton({
  label,
  shiftLabel,
  alphaLabel,
  variant = "default",
  active,
  onPress,
  className,
  bigLabel,
}: Props) {
  return (
    <div className="flex flex-col items-stretch min-w-0">
      <div className="flex justify-between px-1 h-3 leading-3 text-[9px] font-semibold tracking-tight">
        <span className="text-[var(--calc-shift-fn)] truncate">{shiftLabel ?? "\u00A0"}</span>
        <span className="text-[var(--calc-alpha-fn)] truncate">{alphaLabel ?? "\u00A0"}</span>
      </div>
      <button
        type="button"
        onClick={onPress}
        className={cn(
          "rounded-md select-none transition active:scale-95 active:brightness-90",
          "shadow-[0_1px_0_rgba(255,255,255,0.18)_inset,0_-1px_2px_rgba(0,0,0,0.55)_inset,0_2px_4px_rgba(0,0,0,0.6)]",
          "h-9 sm:h-10 flex items-center justify-center",
          bigLabel ? "text-lg font-semibold" : "text-sm font-medium",
          variantClass[variant],
          active && "ring-2 ring-[var(--calc-key-accent)]",
          className,
        )}
      >
        {label}
      </button>
    </div>
  );
}