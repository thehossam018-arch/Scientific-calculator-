import { useEffect, useState } from "react";
import { CalcButton } from "./CalcButton";
import { TOP_KEYS, BOTTOM_KEYS, type Action, type KeyDef } from "./keypadData";
import { useCalc } from "@/lib/calc/state";
import { evaluate, formatResult } from "@/lib/calc/engine";
import {
  HistoryPanel, MatrixPanel, VectorPanel, StatPanel, SolvePanel, CalcPanel,
  IntegralPanel, DerivPanel, SumPanel, SettingsPanel, type PanelName,
} from "./Panels";
import { Menu, Settings as SettingsIcon, Sigma, ToggleLeft, History as HistoryIcon } from "lucide-react";

function StatusBar() {
  const angle = useCalc((s) => s.angle);
  const display = useCalc((s) => s.display);
  const fraction = useCalc((s) => s.fraction);
  return (
    <div className="flex gap-3 px-2 py-1 text-[10px] font-bold text-[var(--calc-shift-fn)] tracking-wider">
      <span>{display}</span>
      <span>MATH</span>
      <span className={fraction ? "text-[var(--calc-key-accent)]" : ""}>FRAC</span>
      <span className="ml-auto">{angle}</span>
    </div>
  );
}

function Display() {
  const expr = useCalc((s) => s.expr);
  const cursor = useCalc((s) => s.cursor);
  const result = useCalc((s) => s.result);
  const error = useCalc((s) => s.error);
  const before = expr.slice(0, cursor);
  const after = expr.slice(cursor);
  return (
    <div className="rounded-md bg-[var(--calc-display)] text-[var(--calc-display-fg)] h-44 sm:h-52 p-3 flex flex-col">
      <StatusBar />
      <div className="flex-1 font-mono text-lg sm:text-xl break-all overflow-auto leading-snug">
        {before}
        <span className="inline-block w-[2px] h-5 bg-current align-middle animate-pulse" />
        {after}
      </div>
      <div className="font-mono text-2xl sm:text-3xl text-right tabular-nums">
        {error ? <span className="text-red-600 text-base">{error}</span> : result}
      </div>
    </div>
  );
}

function Toolbar({ onOpen }: { onOpen: (p: PanelName) => void }) {
  const angle = useCalc((s) => s.angle);
  const cycle = useCalc((s) => s.cycleAngle);
  const negate = useCalc((s) => s.negateLast);
  return (
    <div className="flex items-center gap-2 px-1 py-2">
      <button onClick={() => onOpen("history")} className="p-1.5 rounded bg-[var(--calc-key)] text-white"><Menu size={16} /></button>
      <span className="text-[10px] font-bold px-2 py-1 rounded bg-[var(--calc-key-alpha)] text-white">PRO</span>
      <button onClick={() => onOpen("sum")} className="p-1.5 rounded bg-[var(--calc-key)] text-white"><Sigma size={16} /></button>
      <button onClick={() => onOpen("settings")} className="p-1.5 rounded bg-[var(--calc-key)] text-white"><SettingsIcon size={16} /></button>
      <button onClick={negate} className="p-1.5 rounded bg-[var(--calc-key)] text-white"><ToggleLeft size={16} /></button>
      <button onClick={cycle} className="ml-auto px-2 py-1 rounded bg-[var(--calc-key)] text-white text-xs font-bold border border-white/20">{angle}</button>
      <button onClick={() => onOpen("history")} className="p-1.5 rounded bg-[var(--calc-key)] text-white"><HistoryIcon size={16} /></button>
    </div>
  );
}

function useDispatch(setPanel: (p: PanelName) => void) {
  const s = useCalc.getState;
  const setMod = useCalc((st) => st.setModifier);
  const modifier = useCalc((st) => st.modifier);
  const twoNd = useCalc((st) => st.twoNd);

  return (def: KeyDef) => {
    let action: Action = def.action;
    if (modifier === "shift" && def.shiftAction) action = def.shiftAction;
    else if (modifier === "alpha" && def.alphaAction) action = def.alphaAction;
    // 2nd toggles inverse trig etc — handled by also showing shift labels.
    if (modifier !== "none" && action === def.action && (def.shiftAction || def.alphaAction)) {
      // user pressed shift/alpha but key has no override: clear modifier, perform base
      setMod("none");
    }
    runAction(action, setPanel);
  };
}

function runAction(action: Action, setPanel: (p: PanelName) => void) {
  const st = useCalc.getState();
  switch (action.type) {
    case "insert": return st.insert(action.text, { advance: action.advance });
    case "shift": return st.setModifier(st.modifier === "shift" ? "none" : "shift");
    case "alpha": return st.setModifier(st.modifier === "alpha" ? "none" : "alpha");
    case "twoNd": return st.toggle2nd();
    case "left": return st.moveCursor(-1);
    case "right": return st.moveCursor(1);
    case "up": case "down": return; // reserved for history nav
    case "del": return st.backspace();
    case "ac": return st.clearAll();
    case "equals": return st.evaluateNow();
    case "negate": return st.negateLast();
    case "angle": return st.cycleAngle();
    case "frac": return st.toggleFraction();
    case "ans": return st.insert("Ans");
    case "preAns": return st.insert("PreAns");
    case "openPanel": return setPanel(action.panel);
    case "storePrompt": {
      const name = window.prompt("Store Ans into variable (A-F, x, y, M):", "A");
      if (name) st.storeVar(name);
      return;
    }
    case "recallPrompt": {
      const vars = useCalc.getState().vars;
      const list = Object.keys(vars).join(", ") || "(empty)";
      const name = window.prompt(`Recall variable [${list}]:`, "A");
      if (name) st.recallVar(name);
      return;
    }
    case "clearVars": return st.clearVars();
  }
}

export function Calculator() {
  const [panel, setPanel] = useState<PanelName>(null);
  const dispatch = useDispatch(setPanel);
  const modifier = useCalc((s) => s.modifier);

  // Physical keyboard
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const st = useCalc.getState();
      const k = e.key;
      if (/^[0-9.]$/.test(k)) { st.insert(k); return; }
      if (k === "+" || k === "-") { st.insert(k); return; }
      if (k === "*") { st.insert("×"); return; }
      if (k === "/") { st.insert("÷"); e.preventDefault(); return; }
      if (k === "(" || k === ")") { st.insert(k); return; }
      if (k === "Enter" || k === "=") { e.preventDefault(); st.evaluateNow(); return; }
      if (k === "Backspace") { e.preventDefault(); st.backspace(); return; }
      if (k === "Escape") { st.clearAll(); return; }
      if (k === "ArrowLeft") { st.moveCursor(-1); return; }
      if (k === "ArrowRight") { st.moveCursor(1); return; }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  return (
    <div className="min-h-screen bg-[var(--calc-bg)] flex items-start sm:items-center justify-center py-2 sm:py-8 px-2">
      <div
        className="w-full max-w-md rounded-2xl p-3 sm:p-4 shadow-2xl border border-white/10"
        style={{ background: "linear-gradient(180deg, #1a1a1a 0%, #000000 100%)" }}
      >
        <Display />
        <Toolbar onOpen={setPanel} />

        <div className="grid grid-cols-6 gap-1.5 mb-2">
          {TOP_KEYS.flat().map((k, i) => (
            <CalcButton
              key={`t-${i}`}
              label={k.label}
              shiftLabel={k.shift}
              alphaLabel={k.alpha}
              variant={k.variant}
              bigLabel={k.bigLabel}
              active={
                (k.action.type === "shift" && modifier === "shift") ||
                (k.action.type === "alpha" && modifier === "alpha")
              }
              onPress={() => dispatch(k)}
            />
          ))}
        </div>

        <div className="grid grid-cols-5 gap-1.5">
          {BOTTOM_KEYS.flat().map((k, i) => (
            <CalcButton
              key={`b-${i}`}
              label={k.label}
              shiftLabel={k.shift}
              alphaLabel={k.alpha}
              variant={k.variant}
              bigLabel={k.bigLabel}
              onPress={() => dispatch(k)}
            />
          ))}
        </div>
      </div>

      <HistoryPanel open={panel === "history"} onClose={() => setPanel(null)} />
      <MatrixPanel open={panel === "matrix"} onClose={() => setPanel(null)} />
      <VectorPanel open={panel === "vector"} onClose={() => setPanel(null)} />
      <StatPanel open={panel === "stat"} onClose={() => setPanel(null)} />
      <SolvePanel open={panel === "solve"} onClose={() => setPanel(null)} />
      <CalcPanel open={panel === "calc"} onClose={() => setPanel(null)} />
      <IntegralPanel open={panel === "integral"} onClose={() => setPanel(null)} />
      <DerivPanel open={panel === "deriv"} onClose={() => setPanel(null)} />
      <SumPanel open={panel === "sum"} onClose={() => setPanel(null)} />
      <SettingsPanel open={panel === "settings"} onClose={() => setPanel(null)} />
    </div>
  );
}