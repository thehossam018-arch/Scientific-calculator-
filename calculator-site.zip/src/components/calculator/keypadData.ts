import type { ReactNode } from "react";

export type Action =
  | { type: "insert"; text: string; advance?: number }
  | { type: "shift" }
  | { type: "alpha" }
  | { type: "twoNd" }
  | { type: "left" }
  | { type: "right" }
  | { type: "up" }
  | { type: "down" }
  | { type: "del" }
  | { type: "ac" }
  | { type: "equals" }
  | { type: "negate" }
  | { type: "angle" }
  | { type: "frac" }
  | { type: "openPanel"; panel: "history" | "matrix" | "vector" | "stat" | "solve" | "calc" | "integral" | "deriv" | "sum" | "settings" }
  | { type: "storePrompt" }
  | { type: "recallPrompt" }
  | { type: "clearVars" }
  | { type: "ans" }
  | { type: "preAns" };

export interface KeyDef {
  label: string;
  shift?: string;
  alpha?: string;
  variant?: "default" | "num" | "op" | "accent" | "alpha" | "danger";
  bigLabel?: boolean;
  action: Action; // base action
  shiftAction?: Action;
  alphaAction?: Action;
}

// Top rows (6 columns) — function block above the number pad.
export const TOP_KEYS: KeyDef[][] = [
  [
    { label: "SHIFT", variant: "accent", action: { type: "shift" } },
    { label: "ALPHA", variant: "alpha", action: { type: "alpha" } },
    { label: "◄", variant: "accent", action: { type: "left" } },
    { label: "►", variant: "accent", action: { type: "right" } },
    { label: "MODE", action: { type: "openPanel", panel: "settings" } },
    { label: "2nd", action: { type: "twoNd" } },
  ],
  [
    { label: "CALC", shift: "SOLVE", action: { type: "openPanel", panel: "calc" }, shiftAction: { type: "openPanel", panel: "solve" } },
    { label: "∫dx", shift: "d/dx", action: { type: "openPanel", panel: "integral" }, shiftAction: { type: "openPanel", panel: "deriv" } },
    { label: "▲", variant: "accent", action: { type: "up" } },
    { label: "▼", variant: "accent", action: { type: "down" } },
    { label: "x⁻¹", shift: "x!", action: { type: "insert", text: "⁻¹" }, shiftAction: { type: "insert", text: "!" } },
    { label: "Logₓy", shift: "Σ", action: { type: "insert", text: "log(" }, shiftAction: { type: "openPanel", panel: "sum" } },
  ],
  [
    { label: "x/y", shift: "÷R", action: { type: "insert", text: "/" } },
    { label: "√x", shift: "³√x", action: { type: "insert", text: "√(", advance: 2 }, shiftAction: { type: "insert", text: "³√(", advance: 3 } },
    { label: "x²", shift: "x³", action: { type: "insert", text: "²" }, shiftAction: { type: "insert", text: "³" } },
    { label: "xʸ", shift: "ˣ√y", action: { type: "insert", text: "^(", advance: 2 } },
    { label: "Log", shift: "10ˣ", action: { type: "insert", text: "log10(", advance: 6 }, shiftAction: { type: "insert", text: "10^(", advance: 4 } },
    { label: "Ln", shift: "eˣ", action: { type: "insert", text: "log(", advance: 4 }, shiftAction: { type: "insert", text: "e^(", advance: 3 } },
  ],
  [
    { label: "(-)", shift: "∠", alpha: "a", action: { type: "insert", text: "-" }, alphaAction: { type: "recallPrompt" } },
    { label: "°'\"", shift: "FACT", alpha: "b", action: { type: "insert", text: "°" }, shiftAction: { type: "insert", text: "!" } },
    { label: "hyp", shift: "|x|", alpha: "c", action: { type: "insert", text: "" }, shiftAction: { type: "insert", text: "abs(", advance: 4 } },
    { label: "Sin", shift: "Sin⁻¹", alpha: "d", action: { type: "insert", text: "sin(", advance: 4 }, shiftAction: { type: "insert", text: "asin(", advance: 5 } },
    { label: "Cos", shift: "Cos⁻¹", alpha: "e", action: { type: "insert", text: "cos(", advance: 4 }, shiftAction: { type: "insert", text: "acos(", advance: 5 } },
    { label: "Tan", shift: "Tan⁻¹", alpha: "f", action: { type: "insert", text: "tan(", advance: 4 }, shiftAction: { type: "insert", text: "atan(", advance: 5 } },
  ],
  [
    { label: "RCL", shift: "STO", alpha: "CLRv", action: { type: "recallPrompt" }, shiftAction: { type: "storePrompt" }, alphaAction: { type: "clearVars" } },
    { label: "ENG", shift: "i", alpha: "Cot", action: { type: "insert", text: "E" }, shiftAction: { type: "insert", text: "i" } },
    { label: "(", shift: "%", action: { type: "insert", text: "(" }, shiftAction: { type: "insert", text: "/100" } },
    { label: ")", shift: "Cot⁻¹", alpha: ",", action: { type: "insert", text: ")" }, alphaAction: { type: "insert", text: "," } },
    { label: "S⇔D", shift: "x→y", alpha: "y", action: { type: "frac" } },
    { label: "M+", shift: "M-", alpha: "m", action: { type: "storePrompt" } },
  ],
];

// Bottom rows (5 columns) — number pad + AC/DEL + main operators + bottom row.
export const BOTTOM_KEYS: KeyDef[][] = [
  [
    { label: "7", variant: "num", bigLabel: true, shift: "CONST", action: { type: "insert", text: "7" } },
    { label: "8", variant: "num", bigLabel: true, shift: "CONV", action: { type: "insert", text: "8" } },
    { label: "9", variant: "num", bigLabel: true, shift: "SI", action: { type: "insert", text: "9" } },
    { label: "⌫", variant: "danger", bigLabel: true, action: { type: "del" } },
    { label: "AC", variant: "danger", bigLabel: true, shift: "CLR ALL", action: { type: "ac" } },
  ],
  [
    { label: "4", variant: "num", bigLabel: true, shift: "MATRIX", action: { type: "insert", text: "4" }, shiftAction: { type: "openPanel", panel: "matrix" } },
    { label: "5", variant: "num", bigLabel: true, shift: "VECTOR", action: { type: "insert", text: "5" }, shiftAction: { type: "openPanel", panel: "vector" } },
    { label: "6", variant: "num", bigLabel: true, shift: "FUNC", action: { type: "insert", text: "6" } },
    { label: "×", variant: "op", bigLabel: true, shift: "nPr", action: { type: "insert", text: "×" }, shiftAction: { type: "insert", text: " permutations(", advance: 14 } },
    { label: "÷", variant: "op", bigLabel: true, shift: "nCr", action: { type: "insert", text: "÷" }, shiftAction: { type: "insert", text: " combinations(", advance: 14 } },
  ],
  [
    { label: "1", variant: "num", bigLabel: true, shift: "STAT", action: { type: "insert", text: "1" }, shiftAction: { type: "openPanel", panel: "stat" } },
    { label: "2", variant: "num", bigLabel: true, shift: "CMPLX", action: { type: "insert", text: "2" } },
    { label: "3", variant: "num", bigLabel: true, shift: "DISTR", action: { type: "insert", text: "3" } },
    { label: "+", variant: "op", bigLabel: true, shift: "Pol", action: { type: "insert", text: "+" } },
    { label: "−", variant: "op", bigLabel: true, shift: "Rec", action: { type: "insert", text: "-" } },
  ],
  [
    { label: "0", variant: "num", bigLabel: true, shift: "COPY", action: { type: "insert", text: "0" } },
    { label: ".", variant: "num", bigLabel: true, shift: "Ran#", action: { type: "insert", text: "." }, shiftAction: { type: "insert", text: String(Math.random()) } },
    { label: "Exp", variant: "num", bigLabel: true, shift: "π", alpha: "e", action: { type: "insert", text: "E" }, shiftAction: { type: "insert", text: "π" }, alphaAction: { type: "insert", text: "e" } },
    { label: "Ans", variant: "op", bigLabel: true, shift: "PreAns", action: { type: "insert", text: "Ans" }, shiftAction: { type: "insert", text: "PreAns" } },
    { label: "=", variant: "accent", bigLabel: true, shift: "History", action: { type: "equals" }, shiftAction: { type: "openPanel", panel: "history" } },
  ],
];