import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Drawer, DrawerContent, DrawerHeader, DrawerTitle } from "@/components/ui/drawer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useCalc } from "@/lib/calc/state";
import { math, evaluate as evalExpr } from "@/lib/calc/engine";

export type PanelName =
  | "history" | "matrix" | "vector" | "stat" | "solve" | "calc"
  | "integral" | "deriv" | "sum" | "settings" | null;

export function HistoryPanel({ open, onClose }: { open: boolean; onClose: () => void }) {
  const history = useCalc((s) => s.history);
  const load = useCalc((s) => s.loadFromHistory);
  return (
    <Drawer open={open} onOpenChange={(o) => !o && onClose()}>
      <DrawerContent>
        <DrawerHeader>
          <DrawerTitle>History</DrawerTitle>
        </DrawerHeader>
        <div className="px-4 pb-6 max-h-[60vh] overflow-auto space-y-2">
          {history.length === 0 && <div className="text-sm text-muted-foreground">No history yet</div>}
          {history.map((h, i) => (
            <button
              key={i}
              className="w-full text-left p-3 rounded-md bg-secondary hover:bg-accent"
              onClick={() => { load(h); onClose(); }}
            >
              <div className="font-mono text-sm truncate">{h.expr}</div>
              <div className="font-mono text-xs text-muted-foreground">= {h.result}</div>
            </button>
          ))}
        </div>
      </DrawerContent>
    </Drawer>
  );
}

function SimpleResultDialog({
  open, onClose, title, render,
}: { open: boolean; onClose: () => void; title: string; render: (close: () => void) => React.ReactNode }) {
  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-md">
        <DialogHeader><DialogTitle>{title}</DialogTitle></DialogHeader>
        {render(onClose)}
      </DialogContent>
    </Dialog>
  );
}

export function SolvePanel({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [expr, setExpr] = useState("x^2 - 4");
  const [guess, setGuess] = useState("1");
  const [result, setResult] = useState<string | null>(null);
  const solve = () => {
    try {
      const f = math.compile(expr);
      let x = parseFloat(guess);
      const eps = 1e-7;
      for (let i = 0; i < 100; i++) {
        const fx = Number(f.evaluate({ x }));
        const fxh = Number(f.evaluate({ x: x + eps }));
        const dfx = (fxh - fx) / eps;
        if (!isFinite(dfx) || dfx === 0) break;
        const next = x - fx / dfx;
        if (Math.abs(next - x) < 1e-10) { x = next; break; }
        x = next;
      }
      setResult(`x ≈ ${x}`);
    } catch (e) { setResult((e as Error).message); }
  };
  return (
    <SimpleResultDialog open={open} onClose={onClose} title="SOLVE  f(x) = 0" render={() => (
      <div className="space-y-3">
        <Label>Expression in x</Label>
        <Input value={expr} onChange={(e) => setExpr(e.target.value)} className="font-mono" />
        <Label>Initial guess</Label>
        <Input value={guess} onChange={(e) => setGuess(e.target.value)} className="font-mono" />
        <Button onClick={solve} className="w-full">Solve</Button>
        {result && <div className="font-mono p-2 bg-secondary rounded">{result}</div>}
      </div>
    )} />
  );
}

export function CalcPanel({ open, onClose }: { open: boolean; onClose: () => void }) {
  const expr = useCalc((s) => s.expr);
  const angle = useCalc((s) => s.angle);
  const ans = useCalc((s) => s.ans);
  const preAns = useCalc((s) => s.preAns);
  const vars = useCalc((s) => s.vars);
  const [val, setVal] = useState("0");
  const [out, setOut] = useState<string | null>(null);
  const compute = () => {
    const r = evalExpr(expr, angle, ans, preAns, { ...vars, x: parseFloat(val) });
    setOut(r.ok ? String(r.value) : r.error);
  };
  return (
    <SimpleResultDialog open={open} onClose={onClose} title="CALC — evaluate at x =" render={() => (
      <div className="space-y-3">
        <div className="font-mono text-xs text-muted-foreground break-all">{expr || "(no expression)"}</div>
        <Input value={val} onChange={(e) => setVal(e.target.value)} className="font-mono" />
        <Button onClick={compute} className="w-full">Compute</Button>
        {out && <div className="font-mono p-2 bg-secondary rounded">{out}</div>}
      </div>
    )} />
  );
}

export function IntegralPanel({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [expr, setExpr] = useState("x^2");
  const [a, setA] = useState("0");
  const [b, setB] = useState("1");
  const [out, setOut] = useState<string | null>(null);
  const compute = () => {
    try {
      const f = math.compile(expr);
      const an = parseFloat(a), bn = parseFloat(b);
      const n = 1000;
      const h = (bn - an) / n;
      let s = 0;
      for (let i = 0; i <= n; i++) {
        const x = an + i * h;
        const w = i === 0 || i === n ? 1 : i % 2 === 0 ? 2 : 4;
        s += w * Number(f.evaluate({ x }));
      }
      setOut(String((h / 3) * s));
    } catch (e) { setOut((e as Error).message); }
  };
  return (
    <SimpleResultDialog open={open} onClose={onClose} title="∫ f(x) dx" render={() => (
      <div className="space-y-3">
        <Label>f(x)</Label>
        <Input value={expr} onChange={(e) => setExpr(e.target.value)} className="font-mono" />
        <div className="grid grid-cols-2 gap-2">
          <div><Label>a</Label><Input value={a} onChange={(e) => setA(e.target.value)} className="font-mono" /></div>
          <div><Label>b</Label><Input value={b} onChange={(e) => setB(e.target.value)} className="font-mono" /></div>
        </div>
        <Button onClick={compute} className="w-full">Integrate</Button>
        {out && <div className="font-mono p-2 bg-secondary rounded">{out}</div>}
      </div>
    )} />
  );
}

export function DerivPanel({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [expr, setExpr] = useState("x^2");
  const [at, setAt] = useState("1");
  const [out, setOut] = useState<string | null>(null);
  const compute = () => {
    try {
      const sym = math.derivative(expr, "x").toString();
      const v = math.evaluate(expr, { x: parseFloat(at) });
      const dv = math.evaluate(sym, { x: parseFloat(at) });
      setOut(`d/dx = ${sym}\nat x=${at}: ${dv}\nf(x) = ${v}`);
    } catch (e) { setOut((e as Error).message); }
  };
  return (
    <SimpleResultDialog open={open} onClose={onClose} title="d/dx" render={() => (
      <div className="space-y-3">
        <Label>f(x)</Label>
        <Input value={expr} onChange={(e) => setExpr(e.target.value)} className="font-mono" />
        <Label>at x =</Label>
        <Input value={at} onChange={(e) => setAt(e.target.value)} className="font-mono" />
        <Button onClick={compute} className="w-full">Differentiate</Button>
        {out && <pre className="font-mono p-2 bg-secondary rounded whitespace-pre-wrap text-sm">{out}</pre>}
      </div>
    )} />
  );
}

export function SumPanel({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [expr, setExpr] = useState("k");
  const [from, setFrom] = useState("1");
  const [to, setTo] = useState("10");
  const [out, setOut] = useState<string | null>(null);
  const compute = () => {
    try {
      const f = math.compile(expr);
      let s = 0;
      const a = parseInt(from), b = parseInt(to);
      for (let k = a; k <= b; k++) s += Number(f.evaluate({ k }));
      setOut(String(s));
    } catch (e) { setOut((e as Error).message); }
  };
  return (
    <SimpleResultDialog open={open} onClose={onClose} title="Σ — Summation" render={() => (
      <div className="space-y-3">
        <Label>Expression in k</Label>
        <Input value={expr} onChange={(e) => setExpr(e.target.value)} className="font-mono" />
        <div className="grid grid-cols-2 gap-2">
          <div><Label>from</Label><Input value={from} onChange={(e) => setFrom(e.target.value)} className="font-mono" /></div>
          <div><Label>to</Label><Input value={to} onChange={(e) => setTo(e.target.value)} className="font-mono" /></div>
        </div>
        <Button onClick={compute} className="w-full">Sum</Button>
        {out && <div className="font-mono p-2 bg-secondary rounded">{out}</div>}
      </div>
    )} />
  );
}

export function MatrixPanel({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [a, setA] = useState("[[1,2],[3,4]]");
  const [b, setB] = useState("[[5,6],[7,8]]");
  const [out, setOut] = useState<string | null>(null);
  const run = (op: "add" | "mul" | "det" | "inv" | "transpose") => {
    try {
      const A = math.evaluate(a), B = math.evaluate(b);
      let r: unknown;
      if (op === "add") r = math.add(A as never, B as never);
      else if (op === "mul") r = math.multiply(A as never, B as never);
      else if (op === "det") r = math.det(A as never);
      else if (op === "inv") r = math.inv(A as never);
      else r = math.transpose(A as never);
      setOut(math.format(r, { precision: 6 }));
    } catch (e) { setOut((e as Error).message); }
  };
  return (
    <SimpleResultDialog open={open} onClose={onClose} title="Matrix" render={() => (
      <div className="space-y-3">
        <Label>A</Label>
        <Input value={a} onChange={(e) => setA(e.target.value)} className="font-mono" />
        <Label>B</Label>
        <Input value={b} onChange={(e) => setB(e.target.value)} className="font-mono" />
        <div className="grid grid-cols-3 gap-2">
          <Button variant="secondary" onClick={() => run("add")}>A+B</Button>
          <Button variant="secondary" onClick={() => run("mul")}>A×B</Button>
          <Button variant="secondary" onClick={() => run("transpose")}>Aᵀ</Button>
          <Button variant="secondary" onClick={() => run("det")}>det A</Button>
          <Button variant="secondary" onClick={() => run("inv")}>A⁻¹</Button>
        </div>
        {out && <pre className="font-mono p-2 bg-secondary rounded whitespace-pre-wrap text-sm">{out}</pre>}
      </div>
    )} />
  );
}

export function VectorPanel({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [u, setU] = useState("[1,2,3]");
  const [v, setV] = useState("[4,5,6]");
  const [out, setOut] = useState<string | null>(null);
  const run = (op: "dot" | "cross" | "magU" | "magV" | "add") => {
    try {
      const U = math.evaluate(u), V = math.evaluate(v);
      let r: unknown;
      if (op === "dot") r = math.dot(U as never, V as never);
      else if (op === "cross") r = math.cross(U as never, V as never);
      else if (op === "magU") r = math.norm(U as never);
      else if (op === "magV") r = math.norm(V as never);
      else r = math.add(U as never, V as never);
      setOut(math.format(r, { precision: 6 }));
    } catch (e) { setOut((e as Error).message); }
  };
  return (
    <SimpleResultDialog open={open} onClose={onClose} title="Vector" render={() => (
      <div className="space-y-3">
        <Label>u</Label>
        <Input value={u} onChange={(e) => setU(e.target.value)} className="font-mono" />
        <Label>v</Label>
        <Input value={v} onChange={(e) => setV(e.target.value)} className="font-mono" />
        <div className="grid grid-cols-3 gap-2">
          <Button variant="secondary" onClick={() => run("add")}>u+v</Button>
          <Button variant="secondary" onClick={() => run("dot")}>u·v</Button>
          <Button variant="secondary" onClick={() => run("cross")}>u×v</Button>
          <Button variant="secondary" onClick={() => run("magU")}>|u|</Button>
          <Button variant="secondary" onClick={() => run("magV")}>|v|</Button>
        </div>
        {out && <pre className="font-mono p-2 bg-secondary rounded whitespace-pre-wrap text-sm">{out}</pre>}
      </div>
    )} />
  );
}

export function StatPanel({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [data, setData] = useState("1, 2, 3, 4, 5, 6, 7");
  const [out, setOut] = useState<string | null>(null);
  const compute = () => {
    try {
      const arr = data.split(",").map((s) => parseFloat(s.trim())).filter((n) => !isNaN(n));
      const a = arr as number[];
      const lines = [
        `n = ${a.length}`,
        `Σx = ${math.sum(a)}`,
        `mean = ${math.mean(a)}`,
        `median = ${math.median(a)}`,
        `min = ${math.min(a)}, max = ${math.max(a)}`,
        `σ (pop) = ${math.std(a, "uncorrected")}`,
        `s (sample) = ${math.std(a, "unbiased")}`,
        `variance (sample) = ${math.variance(a, "unbiased")}`,
      ];
      setOut(lines.join("\n"));
    } catch (e) { setOut((e as Error).message); }
  };
  return (
    <SimpleResultDialog open={open} onClose={onClose} title="STAT — 1-Var statistics" render={() => (
      <div className="space-y-3">
        <Label>Data (comma-separated)</Label>
        <Input value={data} onChange={(e) => setData(e.target.value)} className="font-mono" />
        <Button onClick={compute} className="w-full">Compute</Button>
        {out && <pre className="font-mono p-2 bg-secondary rounded whitespace-pre-wrap text-sm">{out}</pre>}
      </div>
    )} />
  );
}

export function SettingsPanel({ open, onClose }: { open: boolean; onClose: () => void }) {
  const angle = useCalc((s) => s.angle);
  const cycle = useCalc((s) => s.cycleAngle);
  const display = useCalc((s) => s.display);
  const setDisplay = (d: typeof display) => useCalc.setState({ display: d });
  const clearVars = useCalc((s) => s.clearVars);
  return (
    <SimpleResultDialog open={open} onClose={onClose} title="Settings" render={(close) => (
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <span>Angle mode</span>
          <Button variant="secondary" onClick={cycle}>{angle}</Button>
        </div>
        <div className="flex items-center justify-between">
          <span>Display</span>
          <div className="flex gap-1">
            {(["NORM", "SCI", "ENG"] as const).map((m) => (
              <Button key={m} variant={display === m ? "default" : "secondary"} size="sm" onClick={() => setDisplay(m)}>{m}</Button>
            ))}
          </div>
        </div>
        <Button variant="destructive" onClick={() => { clearVars(); close(); }}>Clear all variables</Button>
      </div>
    )} />
  );
}