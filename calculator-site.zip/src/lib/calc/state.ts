import { create } from "zustand";
import { persist } from "zustand/middleware";
import { evaluate, formatResult, type AngleMode, type DisplayMode } from "./engine";

export type Modifier = "none" | "shift" | "alpha" | "2nd";

export interface HistoryItem {
  expr: string;
  result: string;
  at: number;
}

interface CalcState {
  expr: string;
  cursor: number; // position in expr
  result: string;
  error: string | null;
  ans: number | null;
  preAns: number | null;
  modifier: Modifier;
  twoNd: boolean;
  angle: AngleMode;
  display: DisplayMode;
  fraction: boolean; // S<=>D toggle
  vars: Record<string, number>;
  history: HistoryItem[];

  // actions
  insert: (text: string, opts?: { advance?: number }) => void;
  backspace: () => void;
  clearAll: () => void;
  moveCursor: (delta: number) => void;
  setCursor: (pos: number) => void;
  setModifier: (m: Modifier) => void;
  toggle2nd: () => void;
  cycleAngle: () => void;
  toggleFraction: () => void;
  evaluateNow: () => void;
  loadFromHistory: (h: HistoryItem) => void;
  storeVar: (name: string) => void;
  recallVar: (name: string) => void;
  clearVars: () => void;
  negateLast: () => void;
  replaceAll: (expr: string) => void;
}

export const useCalc = create<CalcState>()(
  persist(
    (set, get) => ({
      expr: "",
      cursor: 0,
      result: "",
      error: null,
      ans: null,
      preAns: null,
      modifier: "none",
      twoNd: false,
      angle: "DEG",
      display: "NORM",
      fraction: false,
      vars: {},
      history: [],

      insert: (text, opts) => {
        const { expr, cursor } = get();
        const next = expr.slice(0, cursor) + text + expr.slice(cursor);
        const advance = opts?.advance ?? text.length;
        set({ expr: next, cursor: cursor + advance, modifier: "none", error: null });
      },
      backspace: () => {
        const { expr, cursor } = get();
        if (cursor === 0) return;
        set({ expr: expr.slice(0, cursor - 1) + expr.slice(cursor), cursor: cursor - 1, error: null });
      },
      clearAll: () =>
        set({ expr: "", cursor: 0, result: "", error: null, modifier: "none" }),
      moveCursor: (delta) =>
        set((s) => ({ cursor: Math.max(0, Math.min(s.expr.length, s.cursor + delta)) })),
      setCursor: (pos) =>
        set((s) => ({ cursor: Math.max(0, Math.min(s.expr.length, pos)) })),
      setModifier: (m) => set({ modifier: m }),
      toggle2nd: () => set((s) => ({ twoNd: !s.twoNd, modifier: "none" })),
      cycleAngle: () =>
        set((s) => ({ angle: s.angle === "DEG" ? "RAD" : s.angle === "RAD" ? "GRAD" : "DEG" })),
      toggleFraction: () => set((s) => ({ fraction: !s.fraction })),
      evaluateNow: () => {
        const { expr, angle, ans, preAns, vars, display, history } = get();
        if (!expr.trim()) return;
        const r = evaluate(expr, angle, ans, preAns, vars);
        if (!r.ok) {
          set({ error: r.error, result: "" });
          return;
        }
        const numeric = typeof r.value === "number" ? r.value : null;
        const formatted = formatResult(r.value, display);
        set({
          result: formatted,
          error: null,
          ans: numeric,
          preAns: ans,
          history: [{ expr, result: formatted, at: Date.now() }, ...history].slice(0, 50),
        });
      },
      loadFromHistory: (h) => set({ expr: h.expr, cursor: h.expr.length, result: h.result, error: null }),
      storeVar: (name) => {
        const { ans, vars } = get();
        if (ans === null) return;
        set({ vars: { ...vars, [name]: ans }, modifier: "none" });
      },
      recallVar: (name) => {
        const { vars } = get();
        if (!(name in vars)) return;
        get().insert(String(vars[name]));
      },
      clearVars: () => set({ vars: {} }),
      negateLast: () => {
        const { expr, cursor } = get();
        // wrap the whole expression in -() if at end
        const next = expr.slice(0, cursor) + "(-1)*" + expr.slice(cursor);
        set({ expr: next, cursor: cursor + 5 });
      },
      replaceAll: (expr) => set({ expr, cursor: expr.length, result: "", error: null }),
    }),
    {
      name: "calc-state-v1",
      partialize: (s) => ({ history: s.history, vars: s.vars, angle: s.angle, display: s.display }),
    },
  ),
);