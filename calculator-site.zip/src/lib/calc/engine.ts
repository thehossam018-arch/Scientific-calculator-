import { create, all, type MathJsInstance } from "mathjs";

const math: MathJsInstance = create(all, {});

export type AngleMode = "DEG" | "RAD" | "GRAD";
export type DisplayMode = "NORM" | "SCI" | "ENG" | "FIX";

/**
 * Convert a "display" expression (with pretty symbols like √, π, ×, ÷, ², ³, ⁻¹, Ans)
 * to a mathjs-evaluable string. Honors angle mode by wrapping trig args.
 */
export function toEvalExpr(
  display: string,
  angle: AngleMode,
  ans: number | null,
  preAns: number | null,
  vars: Record<string, number>,
): string {
  let s = display;

  // Replace pretty operators
  s = s.replace(/×/g, "*").replace(/÷/g, "/").replace(/−/g, "-");
  s = s.replace(/π/g, "(pi)").replace(/∞/g, "Infinity");
  // exponent superscripts
  const supMap: Record<string, string> = {
    "⁰": "0", "¹": "1", "²": "2", "³": "3", "⁴": "4",
    "⁵": "5", "⁶": "6", "⁷": "7", "⁸": "8", "⁹": "9", "⁻": "-",
  };
  s = s.replace(/[⁰¹²³⁴⁵⁶⁷⁸⁹⁻]+/g, (m) => "^(" + [...m].map((c) => supMap[c]).join("") + ")");

  // √( ... )  and  ³√( ... )
  s = s.replace(/³√/g, "cbrt").replace(/√/g, "sqrt");

  // |x|  -> abs(x)  (single-pair, simple)
  s = s.replace(/\|([^|]+)\|/g, "abs($1)");

  // Ans / PreAns
  if (ans !== null) s = s.replace(/\bAns\b/g, `(${ans})`);
  else s = s.replace(/\bAns\b/g, "0");
  if (preAns !== null) s = s.replace(/\bPreAns\b/g, `(${preAns})`);
  else s = s.replace(/\bPreAns\b/g, "0");

  // E (Exp) e.g. 1.2E3 -> (1.2*10^3)
  s = s.replace(/(\d+(?:\.\d+)?)E(-?\d+)/g, "($1*10^($2))");

  if (angle !== "RAD") {
    s = display
      .replace(/×/g, "*").replace(/÷/g, "/").replace(/−/g, "-")
      .replace(/π/g, "(pi)").replace(/∞/g, "Infinity")
      .replace(/[⁰¹²³⁴⁵⁶⁷⁸⁹⁻]+/g, (m) => "^(" + [...m].map((c) => supMap[c]).join("") + ")")
      .replace(/³√/g, "cbrt").replace(/√/g, "sqrt")
      .replace(/\|([^|]+)\|/g, "abs($1)");
    if (ans !== null) s = s.replace(/\bAns\b/g, `(${ans})`);
    else s = s.replace(/\bAns\b/g, "0");
    if (preAns !== null) s = s.replace(/\bPreAns\b/g, `(${preAns})`);
    else s = s.replace(/\bPreAns\b/g, "0");
    s = s.replace(/(\d+(?:\.\d+)?)E(-?\d+)/g, "($1*10^($2))");

    const k = angle === "DEG" ? "(pi/180)" : "(pi/200)";
    const invK = angle === "DEG" ? "(180/pi)" : "(200/pi)";
    s = wrapTrig(s, k, invK);
  }

  return s;
}

function wrapTrig(src: string, k: string, invK: string): string {
  // Walk and wrap arguments of trig functions; convert inverse trig outputs.
  const fwd = ["sin", "cos", "tan"];
  const inv = ["asin", "acos", "atan", "atan2"];
  // mathjs accepts asin/acos/atan; image uses Sin^-1 etc. — those are emitted as asin(...).
  let out = "";
  let i = 0;
  while (i < src.length) {
    let matched = false;
    for (const fn of inv) {
      if (src.startsWith(fn + "(", i)) {
        // Find matching close paren
        const start = i + fn.length;
        const end = matchParen(src, start);
        if (end > 0) {
          out += `(${invK}*${fn}(${src.slice(start + 1, end)}))`;
          i = end + 1;
          matched = true;
          break;
        }
      }
    }
    if (matched) continue;
    for (const fn of fwd) {
      if (
        src.startsWith(fn + "(", i) &&
        // not part of asin/acos/atan
        (i === 0 || !/[a-z]/i.test(src[i - 1]))
      ) {
        const start = i + fn.length;
        const end = matchParen(src, start);
        if (end > 0) {
          out += `${fn}((${k})*(${src.slice(start + 1, end)}))`;
          i = end + 1;
          matched = true;
          break;
        }
      }
    }
    if (matched) continue;
    out += src[i];
    i++;
  }
  return out;
}

function matchParen(s: string, openIdx: number): number {
  if (s[openIdx] !== "(") return -1;
  let depth = 0;
  for (let i = openIdx; i < s.length; i++) {
    if (s[i] === "(") depth++;
    else if (s[i] === ")") {
      depth--;
      if (depth === 0) return i;
    }
  }
  return -1;
}

export function evaluate(
  display: string,
  angle: AngleMode,
  ans: number | null,
  preAns: number | null,
  vars: Record<string, number>,
): { value: unknown; ok: true } | { error: string; ok: false } {
  try {
    const expr = toEvalExpr(display, angle, ans, preAns, vars);
    const scope = { ...vars };
    const value = math.evaluate(expr, scope);
    return { value, ok: true };
  } catch (e) {
    return { error: translateError((e as Error).message), ok: false };
  }
}

function translateError(msg: string): string {
  const m = msg || "";
  // Parenthesis ) expected (char N)
  const paren = m.match(/Parenthesis \) expected \(char (\d+)\)/i);
  if (paren) return `قوس إغلاق ) متوقع (الموضع ${paren[1]})`;
  const parenOpen = m.match(/Parenthesis \( expected \(char (\d+)\)/i);
  if (parenOpen) return `قوس فتح ( متوقع (الموضع ${parenOpen[1]})`;
  const undef = m.match(/Undefined symbol (.+)/i);
  if (undef) return `رمز غير معرّف: ${undef[1]}`;
  const unexpected = m.match(/Unexpected (?:end of expression|part) "?(.+?)"?\s*\(char (\d+)\)/i);
  if (unexpected) return `تعبير غير متوقع "${unexpected[1]}" (الموضع ${unexpected[2]})`;
  const value = m.match(/Value expected \(char (\d+)\)/i);
  if (value) return `قيمة متوقعة (الموضع ${value[1]})`;
  const op = m.match(/Unexpected operator (.+)/i);
  if (op) return `معامل غير متوقع: ${op[1]}`;
  const div = m.match(/Division by zero/i);
  if (div) return "قسمة على صفر";
  const arg = m.match(/Wrong number of arguments/i);
  if (arg) return "عدد وسائط خاطئ";
  const dim = m.match(/Dimension mismatch/i);
  if (dim) return "عدم تطابق الأبعاد";
  if (/syntax/i.test(m)) return "خطأ في الصيغة";
  return `خطأ: ${m}`;
}

export function formatResult(value: unknown, mode: DisplayMode = "NORM", precision = 10): string {
  if (value === undefined || value === null) return "";
  if (typeof value === "number") {
    if (!isFinite(value)) return value.toString();
    if (mode === "SCI") return value.toExponential(precision - 1);
    if (mode === "ENG") {
      const exp = Math.floor(Math.log10(Math.abs(value || 1)) / 3) * 3;
      const m = value / Math.pow(10, exp);
      return `${m.toPrecision(precision)}E${exp}`;
    }
    return math.format(value, { precision });
  }
  try {
    return math.format(value, { precision });
  } catch {
    return String(value);
  }
}

export { math };