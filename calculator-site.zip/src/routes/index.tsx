import { createFileRoute } from "@tanstack/react-router";
import { Calculator } from "@/components/calculator/Calculator";

export const Route = createFileRoute("/")({
  component: Index,
  head: () => ({
    meta: [
      { title: "Scientific Calculator — Free Online Calc with SHIFT, Matrix, ∫dx" },
      { name: "description", content: "Full scientific calculator: trig, log, fractions, matrices, vectors, statistics, derivatives, integrals, complex numbers. Casio-style keypad with SHIFT and ALPHA." },
      { property: "og:title", content: "Scientific Calculator — Online" },
      { property: "og:description", content: "Casio-style scientific calculator with full SHIFT/ALPHA keypad and advanced functions." },
    ],
  }),
});

function Index() {
  return <Calculator />;
}
